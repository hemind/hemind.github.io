/*
 *  AFSoundcardPrivate.h
 *  Diversity
 *
 *  Created by Kok Chen on 8/14/11.
 *  Copyright 2011 Kok Chen, W7AY. All rights reserved.
 *
 */


//  Category of private API for AFInputSoundcard and AFOutputSoundcard

@interface AFSoundcard (privateAPI)

- (void)defaultDeviceChanged:(AudioObjectPropertySelector)selector ;
- (void)setResamplingQualityIndex:(int)value ;
- (void)changeSamplingRate ;
//	device properties
- (AudioUnit)audioUnit ;
- (AUNode)node ;
- (AudioStreamBasicDescription*)streamFormat ;
- (AudioStreamBasicDescription*)physicalFormat ;
- (AudioStreamBasicDescription*)audioUnitBasicDescription ;
- (AFUnitInfo*)audioUnitInfo ;
//	notifications
- (void)removeDeviceListener ;
- (void)addDeviceListener ;

@end

